    var confirm_Yes = "Great!";
    var confirm_No = "Great!";

    function func_click_Y() {
         alert(confirm_Yes);
    }

    function func_click_N() {
        alert(confirm_No);
    }

    